<?php 
include ('conn_bd.php');
$query  = sprintf("select glpihml.glpi_itilcategories.name as Categoria,
count(glpihml.glpi_tickets.itilcategories_id) as Quantidade 
FROM glpihml.glpi_tickets
inner join glpihml.glpi_itilcategories
on glpihml.glpi_tickets.itilcategories_id = glpihml.glpi_itilcategories.id
WHERE
	month(date) = month(now()) AND glpi_tickets.is_deleted = '0' 
    group by glpihml.glpi_itilcategories.name
    order by count(glpihml.glpi_tickets.itilcategories_id) DESC
    limit 5;");
    
$result = $mysqli->query($query);
    
    $data = array();
    foreach ($result as $row){
        $data[] = $row;
    }
$result -> close();

$mysqli-> close();

function utf8ize($d) {
    if (is_array($d)) {
        foreach ($d as $k => $v) {
            $d[$k] = utf8ize($v);
        }
    } else if (is_string ($d)) {
        return utf8_encode($d);
    }
    return $d;
}


print json_encode(utf8ize($data));
?>
